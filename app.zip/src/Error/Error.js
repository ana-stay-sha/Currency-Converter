import React from 'react';
import './Error.css';

class Error extends React.Component {
  render() {
    return (
    <div className='error'>
        <p>404</p>
    </div>
    );
  }
}

export default Error;
