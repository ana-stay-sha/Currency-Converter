import React from 'react';
import './Points.css';

class Points extends React.Component {
  render() {
    return (
    <div className='points'>
        <p>Exchange points</p>
    </div>
    );
  }
}

export default Points;
